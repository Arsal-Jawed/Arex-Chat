const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const mysql = require('mysql');
const fileUpload = require('express-fileupload');
const socket = require('socket.io');
const http = require('http');

const app = express();
app.use(cors());
app.use(bodyParser.json());
app.use(fileUpload());
const users = [{}];

const server = http.createServer(app);
const io = socket(server);

const ConnectDB = async() => {

    const con = mysql.createConnection({
         
        host: "localhost",
        user: "root",
        password: "",
        database: "chat"        
    });

    con.connect((err)=>{
        if(err){console.log(err);}else{console.log("DB Connected");}
    });

    app.post('/signup', async(req,res)=>{

      const  {email,username,profession,city,country,password} = req.body;
      console.log(email);
      const photoFile = req.files.photo;
      const urlname = `/assets/${photoFile.name}`;
      const filePath = `D:/AREX Projects/AREX Chat/Client/arex_chat/public/assets/${photoFile.name}`;

      photoFile.mv(filePath, async(err)=>{

        if(err){res.status(500); console.log(err);}else{

            con.query("insert into users(email,username,profession,city,country,password,photo) values(?,?,?,?,?,?,?)",
            [email,username,profession,city,country,password,urlname],(err,result)=>{
                if(err){res.status(500); console.log(err);}else{
                    res.status(200).json("User Added Successfully"); console.log("User Added Successfully");
                }
            })
        }
      });
});

    app.post('/login', async(req,res)=>{

        const {email,password} = req.body;
        con.query("select * from users where email=? AND password=?",[email,password],(err,result)=>{
            if(err){res.status(500);}else{
                if(result.length>0){
                    res.status(200).json(result);}else{res.status(500).json("Invalid Username or Password");}
        }})});

    app.get('/card', async(req,res)=>{
        console.log("Fetch Request Recieved");
        con.query("select * from users",(err,result)=>{
            if(err){res.status(500);
            }else{res.status(200).json(result);}
        })
    });

    app.post('/forget', async(req,res)=>{
        console.log("forget request recieved");
        const {fmail} = req.body;
        console.log(fmail);
        con.query("select * from users where email=?",[fmail],(err,result)=>{
            if(result.length>0){res.status(200).json(result);}else{res.status(500).json();}
        })
    });

    app.post('/update', async(req,res)=>{
        const {fmail,newpass} = req.body;
        con.query("update users set password=? where email=?",[fmail,newpass],(err,result)=>{
            if(err){res.status(500).json();}else{res.status(200).json();}
        })
    });

    app.post('/room', async (req, res) => {
        console.log("Room Request Received");
        const Room_No = (Math.floor(Math.random() * 900) + 100).toString();
        const { mail1, mail2 } = req.body;
        console.log(mail2);
        con.query("SELECT * FROM rooms WHERE (email1 = ? AND email2 = ?) OR (email1 = ? AND email2 = ?)", [mail1, mail2, mail2, mail1], (err, result) => {
            if (err) {
                console.error("Error executing SQL query:", err);
                res.status(500).json("Internal server error");
            } else {
                if (result.length > 0) {
                    res.status(200).json(result[0].room);
                } else {
                    con.query("INSERT INTO rooms (email1, email2, room) VALUES (?, ?, ?)", [mail1, mail2, Room_No], (err) => {
                        if (err) {
                            console.error("Error inserting into rooms table:", err);
                            res.status(500).json("Internal server error");
                        } else {
                            res.status(200).json(Room_No);
                        }
                    });
                }
            }
        });
    });

    io.on('connection',(socket)=>{

        console.log("Connection Built with");
      
        socket.on("joined",({name})=>{
            
            users[socket.id] = name;
            console.log(`${name} has joined`);
            socket.broadcast.emit('userJoined',{user:"Admin",message:` ${users[socket.id]} has joined`});
            socket.emit('welcome',{user:"Admin",message:`Welcome to the chat, ${users[socket.id]} `})
      })
      socket.on("joinRoom", (room) => {
        console.log("Join Yeh Wala Room");
        socket.join(room);
    });
      socket.on('message',({message,id,room})=>{
          io.to(room).emit('sendMessage',{user:users[id],message,id});
      })
      
      socket.on('disconnect',()=>{
            socket.broadcast.emit('leave',{user:"Admin",message:`${users[socket.id]}  has left`});
          console.log(`user left`);
      })
      });

    app.listen(4500,()=>{console.log("Server Started");});
    server.listen(8000,()=>{console.log("Socket IO Connected");});
}

ConnectDB();