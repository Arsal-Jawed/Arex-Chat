import './App.css'
import { Routes,Route } from 'react-router-dom';
import Start from './components/Start'
import SignUp from './components/SignUp';
import Profiles from './components/Profiles';
import Chat from './components/Chat';
import Forget from './components/Forget';

function App(){
  
  return(<div>

<Routes>
  <Route path='/' element={<Start/>}></Route>
  <Route path='/sign' element={<SignUp/>}></Route>
  <Route path='/profile' element={<Profiles/>}></Route>
  <Route path='/chat' element={<Chat/>}></Route>
  <Route path='/forget' element={<Forget/>}></Route>
</Routes>
  </div>);
}

export default App;