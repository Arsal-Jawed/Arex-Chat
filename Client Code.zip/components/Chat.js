import './chat.css';
import logo from '../assets/sidepic.png';
import ProfileBar from './ProfileBar'
import socketIo from 'socket.io-client';
import Message from "./Message";
import ReactScrollToBottom from "react-scroll-to-bottom";
import { useEffect,useState} from 'react';
import {useLocation} from 'react-router-dom';

let socket;

function Chat(){

    const location = useLocation();
    const {profile} = location.state;
    const StoredData = localStorage.getItem("user");
    const user = JSON.parse(StoredData);
    const [id, setid] = useState("");
    const [messages, setMessages] = useState([]);
    const [name,setName] = useState(user[0].username);
    const [room,setRoom] = useState(profile.room);
    
    const joinRoom = () => {
          socket.emit('joinRoom',room);
    };
    const send = () => {
        const message = document.getElementById('chatInput').value;
        socket.emit('message', { message, id, room});
        document.getElementById('chatInput').value = "";
    }

    useEffect(()=>{
        socket = socketIo('http://192.168.100.115:8000',{transports: ['websocket']});
        socket.on("connect",()=>{
            setid(socket.id);
        })
        joinRoom();
        socket.emit("joined",{name});
        socket.on("welcome",(data)=>{
        setMessages([...messages, data]);
        })
        socket.on('userjoined',(data)=>{
        setMessages([...messages, data]);
        })
        socket.on('leave',(data)=>{
        setMessages([...messages, data]);
        })

        return ()=>{

             socket.off();
        }
    },[]);

    useEffect(() => {
        socket.on('sendMessage', (data) => {
            setMessages([...messages, data]);
            console.log(data.user, data.message, data.id);
        })
        return () => {
            socket.off();
        }
    }, [messages])

    return(
        <div>
            <ProfileBar/>
        <div className='chat-page'>
            <div className='side-pic-container'>
                  <img src={logo} className='side-pic'></img>
            </div>
            <div className='chat-container'>
            <div className='header'>
                       <div className='profileInfo'>
                       <img src={profile.photo} className='chatimg' alt="Profile" />
                       <h2 className='sname'>{profile.username}</h2>
                 </div>
                       </div>
                       <ReactScrollToBottom className="chatBox">
                       {messages.map((item, i) => <Message user={item.id === id ? '' : item.user} message={item.message} classs={item.id === id ? 'right' : 'left'} />)}
                       </ReactScrollToBottom>
                       <div className='inputBox'>
                       <input onKeyPress={(event) => event.key === 'Enter' ? send() : null} type="text" id="chatInput" placeholder='type a message....'/>
                    <button onClick={send} className="sendBtn"><img src='send.png' alt="Send" /></button>
                       </div>
            </div>
            <div className='profile'>
                <img src={profile.photo} className='profile-pic'></img>
                <h2 className='profile-data'>{profile.username}</h2>
                <h2 className='profile-data'>{profile.city}, {profile.country}</h2>
                <h2 className='profile-data'>{profile.profession}</h2>
            </div>
        </div>
        </div>
    );
}

export default Chat;