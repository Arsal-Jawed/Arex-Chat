import './login.css'
import { Link, useNavigate } from 'react-router-dom';
import { useState } from 'react';

function Login({onClose}){
    
    const [email,setEmail] = useState('');
    const [password,setPassword] = useState('');
    const [error,setError] = useState('');
    
    const handleEmail = (e) => {setEmail(e.target.value);}
    const handlePassword = (e) => {setPassword(e.target.value);}
    
    const navigate = useNavigate();

    const Login = async(e) => {
        e.preventDefault();
        if(email.trim()===''||password.trim()===''){
            setError("please enter all credentials");
            return;
        }else{
            const user = {email,password};

            const response = await fetch("http://192.168.100.115:4500/login",{
                method: 'POST',
                body: JSON.stringify(user),
                headers: {'Content-Type':'application/json'}

            });

            if(response.ok){
                setError("");
                onClose();
                const data = await response.json();
                localStorage.clear();
                localStorage.setItem("user",JSON.stringify(data));
                navigate('/profile');
         }else{
            setError("Invalid Username or Password");
         } 
}     
    }
    return(
        <div className='login-overlay'>
        <div className='login_container'>
               <h1 className='login_title'>Login</h1>
               <form onSubmit={Login}>
                <input 
                type='text' 
                placeholder='Enter Email' 
                className='email_field'
                value={email}
                onChange={handleEmail}
                ></input>
                <input 
                type='password' 
                placeholder='Enter Password' 
                className='password_field'
                value={password}
                onChange={handlePassword}
                />
                <button type='submit' className='login_button'>Login</button>
                <Link to='/forget'><button className='forget_pass'>Forgot password ?</button></Link>
                <p className='error'>{error}</p>
                <div className='no_user'>
                    <p className='not_user'>Not a User ?</p>
                    <Link to='/sign' className='sign_link'>Sign Up</Link>
                </div>
                </form>
        </div>
        </div>
    );
}

export default Login;