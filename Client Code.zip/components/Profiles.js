import './profiles.css';
import ProfileBar from './ProfileBar';
import Card from './Card';
import React,{ useState, useEffect } from 'react';

function Profiles(){

  const [cards,setCards] = useState([]);
  const [filtername,setFilterName] = useState('');
  
  const FetchCards = async() => {
    const response = await fetch('http://192.168.100.115:4500/card');
    const data = await response.json();
    setCards(data);
    console.log(cards);
  };

  const handleFilter = (name) => setFilterName(name);

  const filteredCards = cards.filter(card => card.username.toLowerCase().includes(filtername.toLowerCase()));

  useEffect(()=>{
    FetchCards();
  },[]);

    return(
        <div className='profiles-page'>
              
              <div className='bar-container'>
                <ProfileBar handleFilter={handleFilter}/>
              </div>
              <div className='profiles-container'>
                {filteredCards.map((card)=>(

                  <Card
                  photo = {card.photo}
                  username = {card.username}
                  profession = {card.profession}
                  city = {card.city}
                  country = {card.country}
                  email = {card.email}
                  ></Card>
                ))}
              </div>
        </div>
    );
}

export default Profiles;