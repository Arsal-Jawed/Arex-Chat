import './menu.css'
import { Link } from 'react-router-dom';
import logo from '../assets/ArexChatLogo.PNG';
import Login from './Login';
import {useState} from 'react';

function Menu(){
   
    const [isOpen,setOpen] = useState(false);

    const handleOpen = (e) => setOpen(true);
    const handleClose = (e) => setOpen(false);

    return(
        <div className='menu-bar'>

            <div classname='m1'>        
                    <img src={logo} className='menu-logo'></img>
            </div>
            <div>{isOpen && <Login onClose={handleClose}></Login>}</div>
            <div classname='m2'>
                   <div className='nav-bar'>
                    <button className='nav-buttons'>Home</button>
                    <button className='nav-buttons'>About Us</button>
                    <button className='nav-buttons'>Contact</button>
                   </div> 
            </div>

            <div classname='m3'>
                    <div className='sign-bar'>
                    <button className='login' onClick={handleOpen}>Login</button>
                 <Link to='/sign'><button className='signup'>Sign Up</button></Link> 
                    </div>
            </div>
        </div>
    );
}

export default Menu;