import './profilebar.css';
import logo from '../assets/ArexChatLogo.PNG';
import { useState } from 'react';
import { Link,useNavigate } from 'react-router-dom';

function ProfileBar({handleFilter}){

    const [name,setName] = useState('');
    
    const navigate = useNavigate();

    const StoredData = localStorage.getItem("user");
    const user = JSON.parse(StoredData);

    const handleName = (e) => setName(e.target.value);
    const handleSearch = () => handleFilter(name);
    const LogOut = () => navigate('/');

    return(
        <div className='profile-bar'>
            <img src={logo} classname='bar-logo'></img>
            <div className='search-container'>
                <div className='buttons-container'>
                      <button className='bar-button'>Home</button>
                      <button className='bar-button'>About Us</button>
                      <button className='bar-button'>Contact</button>
                </div>
                <div className='searchbar-container'>
                    <input
                    type='text'
                    placeholder='Enter Profile Name'
                    className='profile-field'
                    value={name}
                    onChange={handleName}
                    ></input>
                    <button className='search' onClick={handleSearch}>Search</button>
                </div>
            </div>
            <div className='user-profile'>
                <img className='user-pic' src={user[0].photo}></img>
                <div>
                    <p classname='user-username'>{user[0].username}</p>
                    <p className='user-email'>{user[0].email}</p>
                </div>
            </div>
            <button className='logout' onClick={LogOut}>Log Out</button>
        </div>
    );
}

export default ProfileBar;