import './email.css';
import { useState } from 'react';
import emailjs from 'emailjs-com';

function Email({onClose,name,email}){
   
    const [anymessage,setMessage] = useState('');

    const handleMessage = (e) => setMessage(e.target.value);
    
    const StoredData = localStorage.getItem("user");
    const user = JSON.parse(StoredData);

    const SendEmail = () => {

            const templateParams = {
                reciever: name,
                sender: user[0].username,
                message: anymessage,
                mail: email
            };
    
            emailjs.send(
                "service_6hgskhi",
                "template_lhfimu3",
                templateParams,
                "rkK8BlY_2kRNb7Fzw"
            );
            onClose();
        
    }

    return(
        <div className='email-overlay'>
        <div className='email-container'>    
              <h1 className='email-title'>Sending Request to {name}</h1>
              <textarea
              className='email-message'
              placeholder='Any Message for Reciever.....'
              type='text'
              value={anymessage}
              onChange={handleMessage}
              ></textarea>
              <button className='mail' onClick={SendEmail}>Send Request</button>
        </div>
        </div>
    );
}

export default Email;