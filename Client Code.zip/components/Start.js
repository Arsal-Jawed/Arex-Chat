import './start.css'
import { useEffect, useState } from 'react';
import Menu from './Menu';
import logo1 from '../assets/flowing_icons.png';
import group from '../assets/group.png';
import chat from '../assets/chat.png';
import request from '../assets/request.png';
import Login from './Login';
import AOS from 'aos';
import 'aos/dist/aos.css';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faFacebookF, faTwitter, faInstagram, faLinkedinIn } from '@fortawesome/free-brands-svg-icons';

function Start(){

    const [isLogin, setLogin] = useState(false);

    const handleLoginOpen = () => {setLogin(true)}
    const handleLoginClose = () => {setLogin(false)}

    useEffect(() => {
        AOS.init({ once: true });
      }, []);
    return(
        <div>
        <Menu/>
        <div className='start-container'>
               
               <div className='startComp-1'>
                <div className='start-image'></div>
                <div className='start-overlay'></div>
                <div className='login_box'>{isLogin && <Login onClose={handleLoginClose}/>}</div>
                <div className='start-content'>
                    <h2 className='start-discp1'>Embark on a Journey Towards Broadening Your Social Circle with a Progressive Step Forward in Connecting You with Others</h2>
                    <button className='start-chat' onClick={handleLoginOpen}>Start Chatting</button>
                </div>
               </div>
               <div className='startComp-2'>
                <div><p className='start-discp2'>
"Welcome to our vibrant chatting platform, where connections flourish and friendships ignite! Here, we invite you to take a step forward into a world of lively conversations and meaningful interactions. Whether you're seeking like-minded individuals, engaging discussions, or simply a space to unwind, our platform offers the perfect avenue to expand your social circle."</p></div>
                <div><img src={logo1} className='logo1'></img></div>
               </div>
               <div className='startComp-3'>
                <div className='comp3_head'><h1 className='feature_head'>More Features For the Connecting With Others</h1></div>
                <div className='comp3_cards'>
                    <div className='comp3_card'>
                        <img src={chat} className='card_image'></img>
                        <h4 className='card_title'>Chatting</h4>
                        <p className='card_discp'>Engage in real-time conversations with friends, family, and colleagues from anywhere in the world, fostering connections and sharing moments effortlessly</p>
                    </div>
                    <div className='comp3_card'>
                        <img src={request} className='card_image'></img>
                        <h4 className='card_title'>Send Chat Request</h4>
                        <p className='card_discp'>Seamlessly initiate conversations by sending personalized chat requests, extending invitations to connect and delve into meaningful interactions</p>
                    </div>
                    <div className='comp3_card'>
                    <img src={group} className='card_image'></img>
                        <h4 className='card_title'>Group Chat</h4>
                        <p className='card_discp'>Experience the synergy of collective communication with group chats, where ideas converge, discussions flourish, and camaraderie thrives among like-minded individuals</p>
                    </div>
                </div>
               </div>
               <div className='startComp-4'>
        <div className="footer-text" data-aos="fade-up">
        <p className='footer_text1'>Stay connected with us:</p>
        <div className="social-icons">
        <a href="#"><FontAwesomeIcon icon={faFacebookF} /></a>
        <a href="#"><FontAwesomeIcon icon={faTwitter} /></a>
        <a href="#"><FontAwesomeIcon icon={faInstagram} /></a>
        <a href="#"><FontAwesomeIcon icon={faLinkedinIn} /></a>
        </div>
      </div>
               </div>
        </div>
        </div>
    )
}

export default Start;