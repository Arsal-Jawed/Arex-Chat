import './card.css';
import { useState } from 'react';
import Email from './Email';
import {useNavigate} from 'react-router-dom';

function Card(props){
    
    const [isEmail,setOpen] = useState(false);

    const handleOpen = (e) => setOpen(true);
    const handleClose = (e) => setOpen(false);

    const navigate = useNavigate();

    const Chat = async() => {
        
        let data;
        const StoredData = localStorage.getItem("user");
        const user = JSON.parse(StoredData);
        
            const mail2 = props.email;
            const mail1 = user[0].email;
            const Check = {
                mail1,
                mail2
            }
            const response = await fetch("http://192.168.100.115:4500/room",{
                method: 'POST',
                body: JSON.stringify(Check),
                headers: {'Content-Type':'application/json'}
            });
    
            data = await response.json();

        const profile = {
            username: props.username,
            profession: props.profession,
            city: props.city,
            country: props.country,
            photo: props.photo,
            room: data
        }
        console.log("Chat Function Called");
        navigate('/chat',{state:{profile}});
    }

    return(
        <div className='card'>
               <div className='mailbox'>
                {isEmail && <Email onClose={handleClose} name={props.username} email={props.email}></Email>}
               </div>
               <img src={props.photo} className='card-pic'></img>
               <p className='card-name1'>{props.username}</p>
               <p className='card-name2'>{props.city}, {props.country}</p>
               <p className='card-name2'>{props.profession}</p>
               <div className='view-container'>
                <button className='chat-button' onClick={Chat}>Chat</button>
                <button className='chat-button' onClick={handleOpen}>Send Request</button>
               </div>
        </div>
    );
}

export default Card;