import './forget.css';
import Menu from './Menu';
import {useState} from 'react';
import {useNavigate} from 'react-router-dom';
import pic from '../assets/forget.png';

function Forget(){

    const [fmail,setFmail] = useState('');
    const [visibility1, setVisibility1] = useState('appear');
    const [visibility2, setVisibility2] = useState('disappear');
    const [error1, setError1] = useState('');
    const [newpass, setNewPass] = useState('');
    const [cpass, setCPass] = useState('');
    const [error2, setError2] = useState('');
    
    const navigate = useNavigate();

    const handleFmail = (e) => setFmail(e.target.value);
    const handleNewPass = (e) => setNewPass(e.target.value);
    const handleCPass = (e) => setCPass(e.target.value);

    const sendRequest = async(e) => {

        e.preventDefault();

        if(fmail.trim()===''){
            setError1("please enter your email");
            return;
        }else{
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if(!emailRegex.test(fmail)){
                setError1("please enter a valid email");
                return;
            }else{

                const mail = {fmail}
                const response = await fetch("http://192.168.100.115:4500/forget",{
                    method: 'POST',
                    body: JSON.stringify(mail),
                    headers: {'Content-Type':'application/json'}
                });

                if(response.ok){
                setError1('');
                setVisibility1('disappear');
                setVisibility2('appear');
                }else{
                    setError1('email does not exist');
                    return;
                }
                
            }
        }
    }

    const UpdatePassword = async(e) => {

        if(newpass.trim()===''){
            setError2('enter a password');
            return;
        }else if(newpass.length < 8 || !/[!@#$%^&*(),.?":{}|<>]/.test(newpass)){
            setError2('password must contain 8 and 1 special character');
            return;
        }else{

            if(cpass.trim()===''){
                setError2('please confirm your password');
            }else{
                if(newpass!==cpass){
                    setError2('passwords does not match');
                }else{

                    const update = {fmail,newpass}
                    const response = await fetch("http://192.168.100.115:4500/update",{
                        method: 'POST',
                        body: JSON.stringify(update),
                        headers: {'Content-Type':'application/json'}
                    });

                    if(response.ok){
                        setError2('');
                        navigate('/');
                    }
                }
            }
        }
    }
    
    return(
        <div>
            <Menu></Menu>
            <div className='forget-container'>
                   
                   <div className='forget-pic-container'>
                    <img src={pic} className='forget-pic'></img>
                   </div>
                   <div className='forget-fields'>
                           <p className='forget-title'>Forget</p>
                           <p className='forget-title'>Password ?</p>
                           <p className='dont-worry'>don't worry, just enter your email, we will update it for you</p>
                           <div className='forget-1' id={visibility1}>
                            <input
                            type='text'
                            placeholder='Enter Your Email'
                            className='fmail'
                            value={fmail}
                            onChange={handleFmail}
                            ></input>
                            <button className='send' onClick={sendRequest}>Send Request</button>
                            <label className='error'>{error1}</label>
                           </div>
                           <div className='forget-2' id={visibility2}>
                            <input
                            type='password'
                            placeholder='Enter New Password'
                            className='fmail'
                            value={newpass}
                            onChange={handleNewPass}
                            ></input>
                            <input
                            type='password'
                            placeholder='Confirm New Password'
                            className='fmail'
                            value={cpass}
                            onChange={handleCPass}
                            ></input>
                            <button className='send' onClick={UpdatePassword}>Update Password</button>
                            <label className='error'>{error2}</label>
                           </div>
                   </div>
            </div>
        </div>
    );
}

export default Forget;