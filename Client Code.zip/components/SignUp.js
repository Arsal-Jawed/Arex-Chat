import './signup.css';
import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import logo from '../assets/signpic.png';
import logo2 from '../assets/ArexChatLogo.PNG';

function SignUp(){

const [email,setEmail] = useState('');
const [username,setUsername] = useState('');
const [profession,setProfession] = useState('');
const [city,setCity] = useState('');
const [country,setCountry] = useState('');
const [password,setPassword] = useState('');
const [confirmpass,setConfirmpass] = useState('');
const [error,setError] = useState('');
const [photo,setPhoto] = useState(null);
const [imagePreviewUrl, setImagePreviewUrl] = useState(null);

const [check1,setCheck1] = useState('right-field');
const [check2,setCheck2] = useState('right-field');
const [check3,setCheck3] = useState('right-field');
const [check4,setCheck4] = useState('right-field');
const [check5,setCheck5] = useState('right-field');
const [check6,setCheck6] = useState('right-field');
const [check7,setCheck7] = useState('right-field');

const handleEmail = (e) => {setEmail(e.target.value);}
const handleUsername = (e) => {setUsername(e.target.value);}
const handleProfession = (e) => {setProfession(e.target.value);}
const handleCity = (e) => {setCity(e.target.value);}
const handleCountry = (e) => {setCountry(e.target.value);}
const handlePassword = (e) => {setPassword(e.target.value);}
const handleConfirmpass = (e) => {setConfirmpass(e.target.value);}
const handlePhoto = (e) => {

    const file = e.target.files[0];
        setPhoto(file);

        if (file) {
            const reader = new FileReader();
            reader.onloadend = () => {
                setImagePreviewUrl(reader.result);
            };
            reader.readAsDataURL(file);
        } else {
            setImagePreviewUrl(null);
        }
}

const navigate = useNavigate();

     const Register = async(e) =>{

         e.preventDefault();
         const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

         if(email.trim()===''){

            setError('please enter your email');
            setCheck1('wrong-field');
            return;

         }else if(!emailRegex.test(email)){

            setError('please enter a valid email');
            setCheck1('wrong-field');
            return;
         }else{

            setError('');
            setCheck1('right-field');
         }

         if(username.trim()===''){
            setError('please enter a username');
            setCheck2('wrong-field');
            return;
         }else{

            setError('');
            setCheck2('right-field');
         }

         if(profession.trim()===''){
            setError('please enter your profession');
            setCheck3('wrong-field');
            return;
         }else{

            setError('');
            setCheck3('right-field');
         }

         if(city.trim()===''){
            setError('please enter your city');
            setCheck4('wrong-field');
            return;
         }else{

            setError('');
            setCheck4('right-field');
         }

         if(country.trim()===''){
            setError('please enter your country');
            setCheck5('wrong-field');
            return;
         }else{
            setError('');
            setCheck5('right-field');
         }

         if(password.trim()===''){
            setError('please set a password');
            setCheck6('wrong-field');
            return;
         }else if(password.length < 8 || !/[!@#$%^&*(),.?":{}|<>]/.test(password)){
            setError('password must contains 8 and 1 special character');
            setCheck6('wrong-field');
            return;
         }else{
            setError('');
            setCheck6('right-field');
         }

         if(confirmpass.trim()===''){
            setError('please confirm your password');
            setCheck7('wrong-field');
            return;
         }else if(password!==confirmpass){
            setError('passwords do not match');
            setCheck7('wrong-field');
            return;
         }else{
            setError('');
            setCheck7('right-field');
         }

         const formData = new FormData();
         formData.append('email',email);
         formData.append('username',username);
         formData.append('profession',profession);
         formData.append('city',city);
         formData.append('country',country);
         formData.append('password',password);
         formData.append('photo', photo);

         const response = await fetch("http://192.168.100.115:4500/signup/", {
            method: 'POST',
            body: formData
         });

         if(response.ok){

            setEmail("");
            setUsername("");
            setProfession("");
            setCity("");
            setCountry("");
            setPassword("");
            setConfirmpass("");
            setError("");

            navigate('/');
         }
     }      

    return(
        <div>
        <div className='signup-container'>
                
                <div className='pic-container'>
                <img src={logo} className='sign-pic'></img>
                </div>
                <div className='sign-container'>
                    <form onSubmit={Register}>
                        <img src={logo2} className='sign-logo'></img>
                        <div>
                        <input 
                        className='sign-field'
                        placeholder='Enter Email'
                        type='text'
                        value={email}
                        onChange={handleEmail}
                        id={check1}
                        ></input>
                        <input 
                        className='sign-field'
                        placeholder='Enter Username'
                        type='text'
                        id={check2}
                        value={username}
                        onChange={handleUsername}
                        ></input>
                        </div>
                        <div>
                        <input 
                        className='sign-field'
                        placeholder='Enter Profession'
                        type='text'
                        id={check3}
                        value={profession}
                        onChange={handleProfession}
                        ></input>
                        </div>
                        <div>
                        <input 
                        className='sign-field'
                        placeholder='Enter City'
                        type='text'
                        id={check4}
                        value={city}
                        onChange={handleCity}
                        ></input>
                        <input 
                        className='sign-field'
                        placeholder='Enter Country'
                        type='text'
                        id={check5}
                        value={country}
                        onChange={handleCountry}
                        ></input>
                        </div>
                        <div>
                        <input 
                        className='sign-field'
                        placeholder='Enter Password'
                        type='password'
                        id={check6}
                        value={password}
                        onChange={handlePassword}
                        ></input>
                        <input 
                        className='sign-field'
                        placeholder='Confirm Password'
                        type='password'
                        id={check7}
                        value={confirmpass}
                        onChange={handleConfirmpass}
                        ></input>
                        </div>
                        <div className='preview-container'>
                        {imagePreviewUrl && <img src={imagePreviewUrl} alt='Preview' style={{ width: '160px', height: '100px', objectFit: 'cover' }} />}
                    </div>
                        <input
                        type="file"
                        accept="image/jpeg, image/png, image/jpg"
                        onChange={handlePhoto}
                        className='photo'
                        ></input>
                        <button type='submit' className='register'>Register</button>
                        <p className='error'>{error}</p>
                    </form>
                </div>
        </div>
        </div>
    );
}

export default SignUp;